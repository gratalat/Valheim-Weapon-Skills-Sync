This mod syncs all your weapon skills so that you can freely switch to different weapon types throughout the playthrough without worrying about having to farm levels again.
Also includes a config to exclude any weapon types from the syncing.
Only syncs levels, not progress to the next level.
(This mod shouldn't have any conflicts with other skill-related mods, unless they fundamentally change how skills work for some reason.)
How it works: When a skill gets raised, the mod will check if any weapon skills are lower level than the highest level weapon skill. Any weapon skills that are under-leveled are silently leveled up. (No annoying level up notifications for skills being synced.)

First mod I've made, apologies if it is buggy.